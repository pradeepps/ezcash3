<?php

include("tablecreating.php");
include("tableupdating.php");

$command=$_GET["com"];

$doctorezcash=intval($_GET["ez"]);
$doctordeviceid=$_GET["ddi"];
$doctorname=$_GET["dn"];
$aboutdoctor=$_GET["ab"];

$patientdeviceid=$_GET["pdi"];
$patientname=$_GET["pn"];

$payment=floatval($_GET["py"]);

$message=$_GET["msg"];

$data="";

if($command=="register"){
createDoctorSubTables($doctorezcash,$doctordeviceid,$doctorname,$aboutdoctor);        
$data="1;";
}

if($command=="doctors"){
$dts=availableDoctors(); 
$data="2;";
foreach ($dts as $dt) {
$data=$data.$dt.";";
}
}

if($command=="pay"){
completePayment($doctorezcash,$patientdeviceid,$payment);
$data="3;".$doctorezcash;
}

if(($command=="save")&&($doctorezcash=="")){
saveDoctorMessage($doctordeviceid,$patientdeviceid,$message);        
$data="4;";
}else if($command=="save"){
savePatientMessage($doctorezcash,$patientdeviceid,$patientname,$message);
setSpend($doctorezcash,$patientdeviceid,5);
$data="5;";
}

if(($command=="read")&&($doctorezcash=="")){
$msg=readPatientMessage($doctordeviceid,$patientdeviceid,FALSE);        
$data="6;";
foreach ($msg as $m) {
$data=$data.$m.";";
}
}else if($command=="read"){
$msg=readDoctorMessage($doctorezcash,$patientdeviceid,FALSE);
$data="7;";
foreach ($msg as $m) {
$data=$data.$m.";";
}
}

?>

<input id="data" type="text" value=<?php echo '"'.$data.'"'?>  />




