<?php

include("userdata.php");

function getCash($ezcash, $patientdeviceid){
$cash=0;

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname = $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass,$dname);

$sql ='SELECT payment FROM payments'.$ezcash.'
WHERE patientdeviceid="'.$patientdeviceid.'"';            
$result=$conn->query($sql);
if($result->num_rows > 0){
$row = $result->fetch_assoc();
$cash=$row['payment'];
}

$conn->close();
return $cash;
}


function getEzcashNumber($doctordeviceid){
$ezcash=0;

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname = $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass,$dname);

$sql ='SELECT ezcash FROM doctors
WHERE doctordeviceid="'.$doctordeviceid.'"';            
$result=$conn->query($sql);
if($result->num_rows > 0){
$row = $result->fetch_assoc();
$ezcash=$row['ezcash'];
}

$conn->close();
return $ezcash;
}


function readDoctorMessage($ezcash, $patientdeviceid,$delete){
$messages=array();
$isfirst=TRUE;

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname = $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass,$dname);

$sql ='SELECT id,message FROM chats'.$ezcash.'
WHERE patientdeviceid="'.$patientdeviceid.'"
AND patientname IS NULL;';            
$result=$conn->query($sql);
if($result->num_rows > 0){
while($row = $result->fetch_assoc()){
	
if($isfirst){
$isfirst=FALSE;
array_push($messages,$ezcash);
}
array_push($messages,$row['message']);

if($delete==TRUE){
$sql =' DELETE FROM chats'.$ezcash.'
WHERE id='.$row['id'].';';
$conn->query($sql);
}

}
}

$conn->close();
return $messages;
}


function readPatientMessage($doctordeviceid, $patientdeviceid,$delete){
$messages=array();
$isfirst=TRUE;

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname = $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass,$dname);

$ezcash=getEzcashNumber($doctordeviceid);

$sql ='SELECT id,patientname,message FROM chats'.$ezcash.'
WHERE patientdeviceid="'.$patientdeviceid.'"
AND patientname IS NOT NULL ;';          
$result=$conn->query($sql);
if($result->num_rows > 0){
while($row = $result->fetch_assoc()){
	
if($isfirst){
$isfirst=FALSE;
array_push($messages,$patientdeviceid);
array_push($messages,$row['patientname']);
}
array_push($messages,$row['message']);

if($delete==TRUE){
$sql =' DELETE FROM chats'.$ezcash.'
WHERE id='.$row['id'].';';
$conn->query($sql);
}

}
}

$conn->close();
return $messages;
}


function availableDoctors(){
$doctors=array();

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname = $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass,$dname);

$sql ='SELECT  ezcash,name,about FROM doctors ;';          
$result=$conn->query($sql);
if($result->num_rows > 0){
while($row = $result->fetch_assoc()){
array_push($doctors,($row['ezcash'].",".$row['name'].",".$row['about']));
}
}

$conn->close();
return $doctors;
}



?>


