<?php

include("tablereading.php");

function completePayment($ezcash, $patientdeviceid, $payment){
$status=TRUE;

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname = $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass,$dname);

$sql='INSERT INTO
payments' .$ezcash.'(patientdeviceid,payment)
VALUES("'.$patientdeviceid.'","'.$payment.'");';
if($conn->query($sql)==FALSE){

$payment=getCash($ezcash, $patientdeviceid)+$payment;

$sql='UPDATE payments'.$ezcash.' 
SET payment='.$payment.'
WHERE patientdeviceid="'.$patientdeviceid.'"'; 
if($conn->query($sql)==FALSE){
$status=FALSE;
}
}

$conn->close();
return $status;
}


function setSpend($ezcash, $patientdeviceid,$spend){
$status=TRUE;

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname = $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass,$dname);

$payment=getCash($ezcash, $patientdeviceid)-$spend;

if($payment<0){
$payment=0;
}

$sql='UPDATE payments'.$ezcash.' 
SET payment='.$payment.'
WHERE patientdeviceid="'.$patientdeviceid.'"'; 
if($conn->query($sql)==FALSE){
$status=FALSE;
}

$conn->close();
return $status;
}


function saveDoctorMessage($doctordeviceid, $patientdeviceid, $message){
$status=TRUE;

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname = $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass,$dname);

$ezcash=getEzcashNumber($doctordeviceid);

$sql='INSERT INTO chats'.$ezcash.'(patientdeviceid,message) 
VALUES("'.$patientdeviceid.'","'.$message.'");';
if($conn->query($sql)==FALSE) {
$status=FALSE;
}

$conn->close();
return $status;
}


function savePatientMessage($ezcash, $patientdeviceid, $patientname,$message){
$status=TRUE;

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname = $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass,$dname);

if(getCash($ezcash,$patientdeviceid)>0){
$sql='INSERT INTO chats'.$ezcash.'(patientdeviceid, patientname, message) 
VALUES("'.$patientdeviceid.'","'.$patientname.'","'.$message.'");';
if($conn->query($sql)==FALSE) {
$status=FALSE;
}
}else{
$message="You can not send messages. Pay now";
$sql='INSERT INTO chats'.$ezcash.'(patientdeviceid,message) 
VALUES("'.$patientdeviceid.'","'.$message.'");';
$conn->query($sql);
}

$conn->close();
return $status;
}



?>





