<?php

include("userdata.php");

function createDatabase(){
$status=TRUE;

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname= $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass);

if($conn->query("CREATE DATABASE ".$dname)==FALSE){
$status=FALSE;
}

$conn->close();
return $status;
}


function createDoctorsTable(){
$status=TRUE;

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname= $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass,$dname);

$sql='CREATE TABLE doctors(
ezcash INTEGER(10) PRIMARY KEY,
doctordeviceid VARCHAR(50) NOT NULL,
name VARCHAR(20) NOT NULL,
about VARCHAR(200));';
if($conn->query($sql)==FALSE){
$status=FALSE;
}

$conn->close();
return $status;
}


function createDoctorSubTables($ezcash,$doctordeviceid,$name,$about){
$status=TRUE;

$dhost =  $GLOBALS["host"];
$duser = $GLOBALS["user"];
$dpass = $GLOBALS["pass"];
$dname= $GLOBALS["dbname"];

$conn=new mysqli($dhost, $duser, $dpass,$dname);

$sql='INSERT INTO 
doctors(ezcash, doctordeviceid, name, about) 
VALUES('.$ezcash.',"'.$doctordeviceid.'","'.$name.'","'.$about.'");';
if($conn->query($sql)==FALSE) {
$status=FALSE;
}

$sql="CREATE TABLE payments".$ezcash."(
patientdeviceid VARCHAR(50) PRIMARY KEY,
payment FLOAT(10) NOT NULL);";
if($conn->query($sql)==FALSE) {
$status=FALSE;
}

$sql="CREATE TABLE chats".$ezcash."(
id INTEGER(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
patientdeviceid VARCHAR(50) NOT NULL,
patientname VARCHAR(20),
message VARCHAR(200));";
if($conn->query($sql)==FALSE) {
$status=FALSE;
}

$conn->close();
return $status;
}

?>





