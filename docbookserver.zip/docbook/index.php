<?php

include("tablecreating.php");
include("tableupdating.php");

createDatabase();
createDoctorsTable();

createDoctorSubTables(2001,"d1","doctor1","i am an expert");
createDoctorSubTables(2002,"d2","doctor2","i am an expert A");

$dts=availableDoctors(); 
$dtst="";
foreach ($dts as $dt) {
$dtst=$dtst.$dt.",";
}


/*completePayment(2001,"ap2s.",2000);
setSpend(2001,"ap2s.",2000);

saveDoctorMessage("saappleo1","ap2s.","do you neyyyehd");
savePatientMessage(2001,"ap2s.","pradeep","yes i nyeed");

$dm= readDoctorMessage(2001,"ap2s.",FALSE);

foreach ($dm as $msg) {
echo $msg."<br>";
}

echo "<br>";

$pm= readPatientMessage("saappleo1","ap2s.",FALSE);

foreach ($pm as $msg) {
echo $msg."<br>";
}
*/


?>


<input id="data" type="text" value=<?php echo '"'.$dtst.'"'?>  />




