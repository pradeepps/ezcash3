<?php

$GLOBALS["host"]="localhost";
$GLOBALS["user"]="data";
$GLOBALS["pass"]="data";
$GLOBALS["dbname"]="docbook";

?>