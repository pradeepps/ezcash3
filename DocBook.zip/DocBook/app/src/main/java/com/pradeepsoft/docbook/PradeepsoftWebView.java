package com.pradeepsoft.docbook;

import android.content.*;
import android.webkit.*;
import java.io.*;
import java.net.*;
import java.util.*;

abstract public class PradeepsoftWebView
{
	WebView web=null;

	public PradeepsoftWebView(Context context)
	{
		web = new WebView(context);
		web.getSettings().setJavaScriptEnabled(true);
		web.addJavascriptInterface(new MyJavaScriptInterface(){
				public void onHTMLReceiveSub(String html)
				{
					String[] htmlL=html.split(";");
					if (htmlL.length > 0)
					{
						if ((htmlL[0].equals("1")) && (htmlL.length > 0))
						{
							onRegister();
							return;
						}
						else	if ((htmlL[0].equals("2")) && (htmlL.length > 1))
						{
							ArrayList<String> lis=new ArrayList<String>();
							for (int a=1;a < htmlL.length;a++)
							{
								if (!htmlL[a].equals(""))
								{
									lis.add(htmlL[a]);
								}
							}
							onDoctors(lis);
							return;
						}
						else if ((htmlL[0].equals("3")) && (htmlL.length > 1))
						{
							onCompletePayment(htmlL[1]);
							return;
						}
						else if ((htmlL[0].equals("4")) && (htmlL.length > 0))
						{
							onSaveDoctorMessage();
							return;
						}
						else if ((htmlL[0].equals("5")) && (htmlL.length > 0))
						{
							onSavePatientMessage();
							return;
						}
						else if ((htmlL[0].equals("6")) && (htmlL.length > 3))
						{
							ArrayList<String> lis=new ArrayList<String>();
							for (int a=3;a < htmlL.length;a++)
							{
								if (!htmlL[a].equals(""))
								{
									lis.add(htmlL[a]);
								}
							}
							onReadPatientMessage(htmlL[1], htmlL[2], lis);
							return;
						}
						else if ((htmlL[0].equals("7")) && (htmlL.length > 2))
						{
							ArrayList<String> lis=new ArrayList<String>();
							for (int a=2;a < htmlL.length;a++)
							{
								if (!htmlL[a].equals(""))
								{
									lis.add(htmlL[a]);
								}
							}
							onReadDoctorMessage(htmlL[1], lis);
							return;
						}
					}
				}
			}, "HtmlViewer");

		web.setWebViewClient(new WebViewClient() 
			{
				@Override
				public void onPageFinished(WebView view, String url) 
				{
					web.loadUrl("javascript:window.HtmlViewer.showHTML(document.getElementById('data').value);");
				}
			});
	}

	public void loadHTML(String url)
	{
		web.loadUrl(url);
	}


	abstract class MyJavaScriptInterface 
	{
		public abstract void onHTMLReceiveSub(String html);

		@JavascriptInterface
		public void showHTML(String html) 
		{
			onHTMLReceiveSub(html);
		}
	}


	public abstract void onRegister();
	public abstract void onDoctors(ArrayList<String> doctors);
	public abstract void onCompletePayment(String ezcash);
	public abstract void onSaveDoctorMessage();
	public abstract void onSavePatientMessage();
	public abstract void onReadPatientMessage(String patientDeviceId, String patientName, ArrayList<String> messages);
	public abstract void onReadDoctorMessage(String doctorEzcash, ArrayList<String> messages);


	public static String registerURL(String serverLink, String doctorEzcash, String doctorDeviceId, String doctorName, String aboutDoctor)
	{
		String url=serverLink + "?com=register";
		try
		{
			url = url + "&ez=" + URLEncoder.encode(doctorEzcash, "UTF-8");
			url = url + "&ddi=" + URLEncoder.encode(doctorDeviceId, "UTF-8");
			url = url + "&dn=" + URLEncoder.encode(doctorName, "UTF-8");
			url = url + "&ab=" + URLEncoder.encode(aboutDoctor, "UTF-8");
		}
		catch (UnsupportedEncodingException ex)
		{
		}
		return url;
	}

	public static String doctorsURL(String serverLink)
	{
		String url=serverLink + "?com=doctors";
		return url;
	}

	public static String completePaymentURL(String serverLink, String doctorEzcash, String patientDeviceId, String payment)
	{
		String url=serverLink + "?com=pay";
		try
		{
			url = url + "&ez=" + URLEncoder.encode(doctorEzcash, "UTF-8");
			url = url + "&pdi=" + URLEncoder.encode(patientDeviceId, "UTF-8");
			url = url + "&py=" + URLEncoder.encode(payment, "UTF-8");
		}
		catch (UnsupportedEncodingException ex)
		{
		}
		return url;
	}


	public static String saveDoctorMessageURL(String serverLink, String doctorDeviceId, String patientDeviceId, String message)
	{
		String url=serverLink + "?com=save";
		try
		{
			url = url + "&ddi=" + URLEncoder.encode(doctorDeviceId, "UTF-8");
			url = url + "&pdi=" + URLEncoder.encode(patientDeviceId, "UTF-8");
			url = url + "&msg=" + URLEncoder.encode(message, "UTF-8");
		}
		catch (UnsupportedEncodingException ex)
		{
		}
		return url;
	}

	public static String savePatientMessageURL(String serverLink, String doctorEzcash, String patientDeviceId, String patientName, String message)
	{
		String url=serverLink + "?com=save";
		try
		{
			url = url + "&ez=" + URLEncoder.encode(doctorEzcash, "UTF-8");
			url = url + "&pdi=" + URLEncoder.encode(patientDeviceId, "UTF-8");
			url = url + "&pn=" + URLEncoder.encode(patientName, "UTF-8");
			url = url + "&msg=" + URLEncoder.encode(message, "UTF-8");
		}
		catch (UnsupportedEncodingException ex)
		{
		}
		return url;
	}


	public static String readPatientMessageURL(String serverLink, String doctorDeviceId, String patientDeviceId)
	{
		String url=serverLink + "?com=read";
		try
		{
			url = url + "&ddi=" + URLEncoder.encode(doctorDeviceId, "UTF-8");
			url = url + "&pdi=" + URLEncoder.encode(patientDeviceId, "UTF-8");
		}
		catch (UnsupportedEncodingException ex)
		{
		}
		return url;
	}

	public static String readDoctorMessageURL(String serverLink, String doctorEzcash, String patientDeviceId)
	{
		String url=serverLink + "?com=read";
		try
		{
			url = url + "&ez=" + URLEncoder.encode(doctorEzcash, "UTF-8");
			url = url + "&pdi=" + URLEncoder.encode(patientDeviceId, "UTF-8");
		}
		catch (UnsupportedEncodingException ex)
		{
		}
		return url;
	}


}
