package com.pradeepsoft.docbook;

public class Payments
{
	long doctorezcash=0;
	double payment=0;
	long time=0;

	static String PAYMENTFILE="payment.db";
}
