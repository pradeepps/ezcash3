package com.pradeepsoft.docbook;

import android.content.*;
import android.os.*;
import android.telephony.*;
import java.util.*;
import java.io.*;
import android.widget.*;

public class EZCash extends BroadcastReceiver
{
	static String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
	//ArrayList<Payments> payments=new ArrayList<Payments>();
	ArrayList<String[]> payments=new ArrayList<String[]>();


	public void onReceive(Context context, Intent intent)
	{
		if (intent.getAction().equals(SMS_RECEIVED))
		{
			Bundle bundle = intent.getExtras();
			if (bundle != null)
			{
				Object[] pdus = (Object[]) bundle.get("pdus");
				if (pdus.length == 0)
				{
					return;
				}
				SmsMessage sms=SmsMessage.createFromPdu((byte[]) pdus[0]);

				readEzCashSms(sms, context);
			}
		}
	}

	public void readEzCashSms(SmsMessage sms, Context context)
	{
		String address=sms.getOriginatingAddress().replace(" ", "").replace("\n", "").toLowerCase();
		String[] body = sms.getMessageBody().replace("\n", " ").toLowerCase().split(" ");

		//Toast toast = Toast.makeText(context, sms.getMessageBody(), Toast.LENGTH_LONG);
		//toast.show();

		if (address.equals("ezcash"))
		{
			if (body.length > 7)
			{
				if (body[2].equals("paid:"))
				{
					try
					{
						if ((body[3].length() >= 9) && (body[6].length() >= 4))
						{
							try
							{
								long number=Long.parseLong(body[3].substring(body[3].length() - 9, body[3].length()));	
								double paid=Double.parseDouble(body[6].substring(3, body[6].length())) ;

								/*Payments py=new Payments();
								 py.doctorezcash=number;
								 py.payment=paid;
								 py.time=new Date().getTime();*/

								String[] py=new String[3];
								py[0] = number + "";
								py[1] = paid + "";
								py[2] = new Date().getTime() + "";

								ArrayList<String[]> payments=new ArrayList<String[]>();
								Object object= ObjectSave.deserialize(context, Payments.PAYMENTFILE);
								if (object != null)
								{
									payments = (ArrayList<String[]>)object;
								}
								payments.add(py);
								ObjectSave.serialize(context, payments, Payments.PAYMENTFILE);

								/*Payments py=new Payments();
								 py.ez_cash_number= number + "";
								 py.payment = paid + "";
								 py.time= new Date().getTime() + "";

								 Object object= ObjectSave.deserialize(context,Payments.file);
								 if(object!=null){
								 payments=(ArrayList<Payments>)object;
								 }
								 payments.add(py);
								 ObjectSave.serialize(context,object,Payments.file);
								 */

								/*String[] py=new String[3];
								 py[0] = number + "";
								 py[1] = paid + "";
								 py[2] = new Date().getTime() + "";

								 Toast toast = Toast.makeText(context, py[0]+"\n"+py[1]+"\n"+py[2], Toast.LENGTH_LONG);
								 toast.show();

								 Object object= ObjectSave.deserialize(context, Payments.file);
								 if (object != null)
								 {
								 payments = (ArrayList<String[]>)object;
								 }
								 payments.add(py);
								 ObjectSave.serialize(context, object, Payments.file);
							 */}
							catch (Exception e)
							{

							}
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
		}
	}

}
