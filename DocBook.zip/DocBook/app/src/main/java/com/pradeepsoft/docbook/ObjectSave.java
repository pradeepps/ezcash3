package com.pradeepsoft.docbook;

import android.content.*;
import java.io.*;

public class ObjectSave
{
	public static void serialize(Context context, Object object, String file)
	{
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		try
		{
			fos = context.openFileOutput(file,Context.MODE_PRIVATE);
			oos = new ObjectOutputStream(fos);
			oos.writeObject(object);
		}
		catch (IOException ex)
		{
		}
		finally
		{
			try
			{
				oos.close();
			}
			catch (Exception ex)
			{
			}
			try
			{
				fos.close();
			}
			catch (Exception ex)
			{
			}
		}
	}

	public static Object deserialize(Context context, String file)
	{
		Object object=null;
		FileInputStream fis=null;
		ObjectInputStream ois=null ;
		try
		{
			fis = context.openFileInput(file);
			ois = new ObjectInputStream(fis);
			try
			{
				object = ois.readObject();
			}
			catch (ClassNotFoundException cex)
			{
			}
		}
		catch (IOException ex)
		{
		}
		finally
		{
			try
			{
				ois.close();
			}
			catch (Exception ex)
			{
			}
			try
			{
				fis.close();
			}
			catch (Exception ex)
			{
			}
		}

		return object;
	}
}
