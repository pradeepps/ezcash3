package com.pradeepsoft.docbook;

public class Chat
{
	String sender_id="";
	String receiver_id="";
	String sender_name="";
	String receiver_name="";
	String message="";
	
	static String CHATFILE="chat.db";
}
