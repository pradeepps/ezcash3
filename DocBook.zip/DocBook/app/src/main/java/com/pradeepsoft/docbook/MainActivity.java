package com.pradeepsoft.docbook;

import android.accounts.*;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.*;
import android.os.*;
import android.telephony.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity 
{
	String myid="";
	String myname="";
	String type="";// doctor or patient
	String mydatafile="mydata.db";

	//ArrayList<Payments> payments=new ArrayList<Payments>();
	//ArrayList<String[]> payments=new ArrayList<String[]>();

	//0-ezcash number, 1-payment, 2-date, 3-id
	//ArrayList<String[]> doctors_to_contact=new ArrayList<String[]>();
//0-id, 1-name, 2-about
	//ArrayList<String[]> all_doctors=new ArrayList<String[]>();
//0-id, 1-name, 2-about, 3-ezcash number
	//ArrayList<String[]> patients_to_contact=new ArrayList<String[]>();
	////0-id, 1-name

	//ArrayList<Chat> chat= new ArrayList<Chat>();
	ArrayList<String[]> chat= new ArrayList<String[]>();




	//Timer ezti=null;
	Timer conn=null;

	Button ez;
	EditText show;
	ScrollView sv;
	Button send;
	EditText text;

	RelativeLayout chatlay;
	int chatsidfrom=10000;
	ArrayList<TextView> chatst =new ArrayList<TextView>();
	//ArrayList<RelativeLayout.LayoutParams> chatsp =new ArrayList<RelativeLayout.LayoutParams>();

	//String html="";
	PradeepsoftWebView web;


	@Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		ez = (Button)findViewById(R.id.ez);
		show = (EditText)findViewById(R.id.show);
		chatlay = (RelativeLayout)findViewById(R.id.chatlay);
		sv = (ScrollView)findViewById(R.id.sv);
		send = (Button)findViewById(R.id.send);
		text = (EditText)findViewById(R.id.text);

		ez.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v)
				{
					if (ez.getText().toString().toLowerCase().equals("pay with ezcash"))
					{
						ez.setText("Complete Payment");
						ezcashCall();
					}
					else if (ez.getText().toString().toLowerCase().equals("complete payment"))
					{
						ez.setText("Pay With EzCash");

						ArrayList<String[]> payments=new ArrayList<String[]>();
						Object object =ObjectSave.deserialize(getApplicationContext(), Payments.PAYMENTFILE);
						if (object != null)
						{
							payments = (ArrayList<String[]>)object;
						}
						String st ="";
						//show.setText(payments.size() + "");

						for (int p=0;p < payments.size();p++)
						{
							st = st + payments.get(p)[0] + "\n" + payments.get(p)[1] + "\n" + payments.get(p)[2] + "\n\n";
						}
						show.setText(st);
					}
				}
			});

		send.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v)
				{
					sendMessage("d1", "Doctor1", text.getText().toString());
					text.setText("");
				}
			});

		//show.setText(myId() + "\n\n" + myName() + "\n" + Toast.LENGTH_LONG);
		init();

	}


	public void init()
	{
		web = new PradeepsoftWebView(getApplicationContext()){
			public  void onRegister()
			{

			}
			public void onDoctors(final ArrayList<String> doctors)
			{

			}
			public  void onCompletePayment(final String ezcash)
			{

			}
			public void onSaveDoctorMessage()
			{

			}
			public  void onSavePatientMessage()
			{

			}
			public  void onReadPatientMessage(final String patientDeviceId, final String patientName, final ArrayList<String> messages)
			{
				show.post(new Runnable(){
						@Override
						public void run() 
						{
							String doc="Doctors" + " : " + patientDeviceId + " : " + patientName + "\n\n";
							doc = ":";
							for (String m:messages)
							{
								doc = doc + m + ":";

							}
							show.setText(doc);

						}});
			}
			public void onReadDoctorMessage(final String doctorEzcash, final ArrayList<String> messages)
			{
				show.post(new Runnable(){
						@Override
						public void run() 
						{
							String doc="Doctors" + " : " + doctorEzcash + " : " + "\n\n";
							for (String m:messages)
							{
								doc = doc + m + "\n";

							}
							show.setText(doc);

						}});
			}
		};

		myid = myId();
		Object ob=ObjectSave.deserialize(getApplicationContext(), Chat.CHATFILE);
		if (ob != null)
		{
			/*chat = (ArrayList<Chat>) ob;
			 for (int a =0;a < chat.size();a++)
			 {
			 Chat ch=chat.get(a);
			 if (ch.sender_id.equals(myid))
			 {
			 showChats(ch.receiver_name + "\n" + ch.message, true);
			 }
			 else if (ch.receiver_id.equals(myid))
			 {
			 showChats(ch.sender_name + "\n" + ch.message, false);
			 }
			 }
			 */
			chat = (ArrayList<String[]>) ob;
			//show.setText(chat.size() + "");
			for (int a =0;a < chat.size();a++)
			{
				String[] ch=chat.get(a);

				if (ch[0].equals(myid))
				{
					showChats(ch[3] + "\n" + ch[4], true);
				}
				else if (ch[1].equals(myid))
				{
					showChats(ch[2] + "\n" + ch[4], false);
				}
			}
		}



	}

	public void ezcashCall()
	{
		startActivity(new Intent("android.intent.action.CALL", Uri.parse("tel:" + Uri.encode("#") + "111" + Uri.encode("#"))));
	}

	public String myId()
	{
		TelephonyManager telemamanger = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		String id =telemamanger.getDeviceId();
		return id;
	}

	public String myName()
	{
		AccountManager accountmanager= AccountManager.get(getApplicationContext());
		Account[] accounts=accountmanager.getAccountsByType("com.google");
		String name="";
		for (Account account : accounts)
		{
			name = account.name.split("@")[0];
		}
		if (name.equals(""))
		{
			return "Unkown";
		}
		return name;
	}

	public void doctorsToContact()
	{

	}

	public void allDoctors()
	{

	}

	public void sendMessage(String receiverid, String receivername, String message)
	{
		//send message (myid + receiver id + message)
		if (!message.replace(" ", "").replace("\n", "").equals(""))
		{
			/*Chat ch=new Chat();
			 ch.sender_id = myid;
			 ch.receiver_id = receiverid;
			 ch.receiver_name = receivername;
			 ch.message = message;
			 chat.add(ch);
			 showChats(ch.receiver_name + "\n" + ch.message, true);
			 */

			String[] ch=new String[5];
			ch[0] = myid;
			ch[1] = receiverid;
			ch[2] = "";
			ch[3] = receivername;
			ch[4] = message;
			chat.add(ch);

			showChats(ch[3] + "\n" + ch[4], true);

		}
	}

	public void receiveMessages()
	{
		conn = new Timer();
		conn.schedule(new TimerTask(){
				public void run()
				{
					runOnUiThread(new Runnable(){
							public void run()
							{
								//send (my id)
								//receive message (sender id +sender name + message)
								/*Chat ch=new Chat();
								 ch.sender_id = "sender id";
								 ch.receiver_id = myid;
								 ch.sender_name = "Sender name";
								 ch.message = "received message";
								 chat.add(ch);
								 showChats(ch.sender_name + "\n" + ch.message, false);
								 */
							}});
					//conn.cancel();
				}
			}, 1000, 2000);
	}

	public void showChats(String text, boolean issent)
	{
		if (issent)
		{
			int currentsize=chatst.size();
			TextView msg=new TextView(this);
			msg.setId(chatsidfrom + currentsize);
			//msg.setBackgroundColor(Color.CYAN);
			msg.setText(text);
			msg.setTextSize(20);
			msg.setPadding(5, 5, 5, 5);
			//msg.setGravity(Gravity.RIGHT);

			GradientDrawable shape = new GradientDrawable();
			shape.setShape(GradientDrawable.RECTANGLE);
			shape.setCornerRadius(10);
			shape.setColor(Color.CYAN);
			//shape.setStroke(1, Color.BLUE);
			msg.setBackground(shape);

			RelativeLayout.LayoutParams laypa=new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
			laypa.setMargins(100, 5, 5, 5);
			if (currentsize == 0)
			{
				laypa.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.ALIGN_TOP);
			}
			else
			{
				laypa.addRule(RelativeLayout.BELOW, chatsidfrom + currentsize - 1);

			}
			laypa.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.ALIGN_RIGHT);

			msg.setLayoutParams(laypa);
			chatlay.addView(msg);
			chatst.add(msg);
		}
		else
		{
			int currentsize=chatst.size();
			TextView msg=new TextView(this);
			msg.setId(chatsidfrom + currentsize);
			//msg.setBackgroundColor(Color.GREEN);
			msg.setText(text);
			msg.setTextSize(20);
			msg.setPadding(5, 5, 5, 5);

			GradientDrawable shape = new GradientDrawable();
			shape.setShape(GradientDrawable.RECTANGLE);
			shape.setCornerRadius(10);
			shape.setColor(Color.GREEN);
			//shape.setStroke(1, Color.BLUE);
			msg.setBackground(shape);

			RelativeLayout.LayoutParams laypa=new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
			laypa.setMargins(5, 5, 100, 5);
			if (currentsize == 0)
			{
				laypa.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.ALIGN_TOP);
			}
			else
			{
				laypa.addRule(RelativeLayout.BELOW, chatsidfrom + currentsize - 1);

			}
			laypa.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.ALIGN_LEFT);

			msg.setLayoutParams(laypa);
			chatlay.addView(msg);
			chatst.add(msg);
		}

		sv.post(new Runnable() {            
				@Override
				public void run()
				{
					sv.fullScroll(View.FOCUS_DOWN);              
				}
			});
	}


	@Override
	protected void onStop()
	{
		// TODO: Implement this method
		super.onStop();

		ObjectSave.serialize(getApplicationContext(), chat, Chat.CHATFILE);

	}	

}
